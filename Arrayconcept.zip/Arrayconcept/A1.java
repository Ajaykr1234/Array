package Arrayconcept;

public class A1 {
	public static void main(String[] args) {
		
		/*Declaration of Array
		int[] arr;
		int arr1[];
		int []arr2;
		
		//intilization of Array
		 arr = new int[3];
		 arr1 = new int[2];
		 arr2 = new int[1];
		 
		 arr = {20,10,10};
  
                          */
		
//		both Declaration and intilization
		int[] arr = new int[3];
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println("=====================================");
		for(int a : arr) {
			System.out.println(a);
		}
		
		
		
		
	}
}