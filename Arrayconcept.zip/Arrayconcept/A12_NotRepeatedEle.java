package Arrayconcept;

public class A12_NotRepeatedEle {
	public static void main(String[] args) {
		
		//Q write a program to find without repeated number in given array
		int[] arr = {1,7,4,2,4,7,8};
		
		int max=arr[0];
		for(int ele: arr) {
			if(max<ele) {
				max=ele;
			}
		}
		
		int[] temp=new int[max+1];
		for(int ele: arr) {
			temp[ele]++;
		}
	
	for(int i=0; i<temp.length; i++) {
		if(temp[i]==1) {   // for repeated value arr[tem]>1
			System.out.println(i);
		}
		
	}
	}
}
