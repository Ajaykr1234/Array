package Arrayconcept;

public class A2 {
public static void main(String[] args) {
	int[] arr = {10,20,30,40};
	System.out.println("0th index number : "+arr[0]);
	System.out.println("1st index number : "+arr[1]);
	System.out.println("2nd index number : "+arr[2]);
	System.out.println("3rd index number : "+arr[3]);
	System.out.println("=========================================================");
      System.out.println("Length of Array : "+arr.length);
      for(int i=0; i<arr.length; i++) {
    	  System.out.println(i+" index number "+arr[i]);
      }
}
}
