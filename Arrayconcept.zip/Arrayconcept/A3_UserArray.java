package Arrayconcept;


import java.util.Scanner;

public class A3_UserArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter yr Array length : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Array got created ..............");
		for(int i=0; i<arr.length; i++) {
			System.out.print(i+" index number : ");
			arr[i]=sc.nextInt();
		}
		System.out.println("Data get stored..........");
		for(int i=0; i<arr.length; i++) {		
			System.out.println(i+" index number is : "+arr[i]);
			
		}
		
	}
}
